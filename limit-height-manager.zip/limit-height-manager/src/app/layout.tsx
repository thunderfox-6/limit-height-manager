import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "限高架智能管家 - 铁路桥涵限高防护架数字台账与预警系统",
  description: "限高架智能管家是一套基于Web的限高架数字管理系统，用于铁路工务段对管内的桥梁、涵洞限高防护架进行数字化管理。系统依据TG/GW 212-2017规范自动校验限高架净高合规性，支持Excel批量导入、预警管理和视频监控。",
  keywords: ["限高架", "铁路桥涵", "数字台账", "预警系统", "TG/GW 212-2017", "工务段"],
  authors: [{ name: "限高架智能管家" }],
  icons: {
    icon: "/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
