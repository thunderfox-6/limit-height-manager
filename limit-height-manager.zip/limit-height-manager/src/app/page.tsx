'use client'

import { useState, useEffect, useCallback } from 'react'
import * as XLSX from 'xlsx'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Checkbox } from '@/components/ui/checkbox'
import { Separator } from '@/components/ui/separator'
import { 
  Train, LogOut, Upload, List, AlertTriangle, ChevronLeft, 
  CheckCircle, XCircle, AlertCircle, Info, RefreshCw, Video,
  FileSpreadsheet, Download, Plus, Edit
} from 'lucide-react'

// 类型定义
interface User {
  id: string
  username: string
  role: string
}

interface LimitPost {
  id: string
  direction: string
  height: number
  structureType: string | null
  installDate: string | null
  lastInspect: string | null
  hasSensor: number
  videoUrl: string | null
  complianceStatus: string
}

interface Bridge {
  id: string
  name: string
  mileage: string
  height: number
  roadLevel: string
  workArea: string
  measureDate: string | null
  downPost: LimitPost | null
  upPost: LimitPost | null
}

interface AlertItem {
  id: string
  level: string
  reason: string
  status: string
  createTime: string
  closeTime: string | null
  bridge: {
    name: string
    mileage: string
    height: number
  }
  post: {
    direction: string
    height: number
  }
}

type View = 'login' | 'list' | 'detail' | 'import' | 'alerts' | 'add' | 'edit'

// 状态颜色映射
const statusColors: Record<string, string> = {
  red: 'bg-red-500 text-white',
  yellow: 'bg-yellow-500 text-white',
  green: 'bg-green-500 text-white',
  blue: 'bg-blue-500 text-white'
}

const statusLabels: Record<string, string> = {
  red: '严重隐患',
  yellow: '余量不足',
  green: '符合规范',
  blue: '限高过严'
}

const roadLevelLabels: Record<string, string> = {
  '国道': '国道',
  '省道': '省道',
  '县道': '县道',
  '城市道路': '城市道路',
  '乡村道路': '乡村道路'
}

// 计算建议净高
const getRecommendedHeight = (bridgeHeight: number): number => {
  return Math.round((bridgeHeight - 0.10) * 100) / 100
}

export default function Home() {
  const [user, setUser] = useState<User | null>(null)
  const [currentView, setCurrentView] = useState<View>('login')
  const [loading, setLoading] = useState(true)
  const [bridges, setBridges] = useState<Bridge[]>([])
  const [workAreas, setWorkAreas] = useState<string[]>([])
  const [alerts, setAlerts] = useState<AlertItem[]>([])
  const [selectedBridge, setSelectedBridge] = useState<Bridge | null>(null)
  
  // 筛选状态
  const [filterWorkArea, setFilterWorkArea] = useState('all')
  const [filterStatus, setFilterStatus] = useState<string[]>([])
  const [filterMileage, setFilterMileage] = useState('')
  
  // 登录表单
  const [loginForm, setLoginForm] = useState({ username: '', password: '' })
  const [loginError, setLoginError] = useState('')
  
  // 导入结果
  const [importResult, setImportResult] = useState<{
    message: string
    successCount: number
    failCount: number
    errors: { row: number; reason: string }[]
  } | null>(null)
  
  // 添加/编辑表单
  const [formData, setFormData] = useState({
    name: '',
    mileage: '',
    height: '',
    roadLevel: '国道',
    workArea: '',
    measureDate: '',
    downHeight: '',
    downStructureType: '',
    downInstallDate: '',
    downHasSensor: false,
    downVideoUrl: '',
    upHeight: '',
    upStructureType: '',
    upInstallDate: '',
    upHasSensor: false,
    upVideoUrl: ''
  })

  // 检查登录状态
  const checkAuth = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/me')
      const data = await res.json()
      if (data.user) {
        setUser(data.user)
        setCurrentView('list')
      }
    } catch {
      setUser(null)
      setCurrentView('login')
    } finally {
      setLoading(false)
    }
  }, [])

  // 初始化数据库
  const initDatabase = useCallback(async () => {
    try {
      await fetch('/api/init')
    } catch (e) {
      console.error('初始化数据库失败', e)
    }
  }, [])

  useEffect(() => {
    initDatabase()
    checkAuth()
  }, [checkAuth, initDatabase])

  // 获取台账列表
  const fetchBridges = useCallback(async () => {
    try {
      const params = new URLSearchParams()
      if (filterWorkArea !== 'all') params.append('workArea', filterWorkArea)
      if (filterStatus.length > 0) params.append('status', filterStatus.join(','))
      if (filterMileage) params.append('mileage', filterMileage)
      
      const res = await fetch(`/api/bridges?${params}`)
      const data = await res.json()
      setBridges(data.bridges || [])
      setWorkAreas(data.workAreas || [])
    } catch (e) {
      console.error('获取台账列表失败', e)
    }
  }, [filterWorkArea, filterStatus, filterMileage])

  useEffect(() => {
    if (user && currentView === 'list') {
      fetchBridges()
    }
  }, [user, currentView, fetchBridges])

  // 获取预警列表
  const fetchAlerts = useCallback(async () => {
    try {
      const res = await fetch('/api/alerts')
      const data = await res.json()
      setAlerts(data.alerts || [])
    } catch (e) {
      console.error('获取预警列表失败', e)
    }
  }, [])

  useEffect(() => {
    if (user && currentView === 'alerts') {
      fetchAlerts()
    }
  }, [user, currentView, fetchAlerts])

  // 登录
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoginError('')
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginForm)
      })
      const data = await res.json()
      if (res.ok) {
        setUser(data.user)
        setCurrentView('list')
      } else {
        setLoginError(data.error || '登录失败')
      }
    } catch {
      setLoginError('登录请求失败')
    }
  }

  // 登出
  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
      setUser(null)
      setCurrentView('login')
    } catch (e) {
      console.error('登出失败', e)
    }
  }

  // 导入Excel
  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    
    setImportResult(null)
    const formData = new FormData()
    formData.append('file', file)
    
    try {
      const res = await fetch('/api/import', {
        method: 'POST',
        body: formData
      })
      const data = await res.json()
      setImportResult(data)
      if (res.ok) {
        fetchBridges()
      }
    } catch (err) {
      setImportResult({
        message: '导入失败',
        successCount: 0,
        failCount: 0,
        errors: [{ row: 0, reason: '网络错误' }]
      })
    }
    e.target.value = ''
  }

  // 查看详情
  const handleViewDetail = async (id: string) => {
    try {
      const res = await fetch(`/api/bridges/${id}`)
      const data = await res.json()
      setSelectedBridge(data.bridge)
      setCurrentView('detail')
    } catch (e) {
      console.error('获取详情失败', e)
    }
  }

  // 重新校验
  const handleRecheck = async () => {
    if (!selectedBridge) return
    try {
      await fetch('/api/check-all', { method: 'POST' })
      const res = await fetch(`/api/bridges/${selectedBridge.id}`)
      const data = await res.json()
      setSelectedBridge(data.bridge)
    } catch (e) {
      console.error('校验失败', e)
    }
  }

  // 更新预警状态
  const handleAlertStatus = async (id: string, status: string) => {
    try {
      await fetch('/api/alerts', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status })
      })
      fetchAlerts()
    } catch (e) {
      console.error('更新预警状态失败', e)
    }
  }

  // 添加新桥涵
  const handleAddBridge = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const res = await fetch('/api/bridges', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })
      if (res.ok) {
        setCurrentView('list')
        fetchBridges()
        setFormData({
          name: '', mileage: '', height: '', roadLevel: '国道', workArea: '',
          measureDate: '', downHeight: '', downStructureType: '', downInstallDate: '',
          downHasSensor: false, downVideoUrl: '', upHeight: '', upStructureType: '',
          upInstallDate: '', upHasSensor: false, upVideoUrl: ''
        })
      }
    } catch (e) {
      console.error('添加失败', e)
    }
  }

  // 下载模板
  const downloadTemplate = () => {
    const template = [
      {
        '桥涵名称': '示例桥涵1',
        '里程': 'K12+345',
        '桥涵净高': 5.20,
        '下行净高': 5.05,
        '上行净高': 5.10,
        '道路等级': '国道',
        '所属工区': '石家庄车间',
        '结构形式': '门式',
        '安装日期': '2023-01-15',
        '有无传感器': 0,
        '视频地址': '',
        '测量日期': '2024-01-01'
      }
    ]
    
    const ws = XLSX.utils.json_to_sheet(template)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, '限高架台账')
    XLSX.writeFile(wb, '限高架台账模板.xlsx')
  }

  // 状态筛选切换
  const toggleStatusFilter = (status: string) => {
    setFilterStatus(prev => 
      prev.includes(status) 
        ? prev.filter(s => s !== status)
        : [...prev, status]
    )
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">加载中...</div>
      </div>
    )
  }

  // 登录页
  if (currentView === 'login') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800 p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Train className="h-12 w-12 text-primary" />
            </div>
            <CardTitle className="text-2xl">限高架智能管家</CardTitle>
            <CardDescription>铁路桥涵限高防护架数字台账与预警系统</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">用户名</Label>
                <Input
                  id="username"
                  value={loginForm.username}
                  onChange={e => setLoginForm(prev => ({ ...prev, username: e.target.value }))}
                  placeholder="请输入用户名"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">密码</Label>
                <Input
                  id="password"
                  type="password"
                  value={loginForm.password}
                  onChange={e => setLoginForm(prev => ({ ...prev, password: e.target.value }))}
                  placeholder="请输入密码"
                  required
                />
              </div>
              {loginError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{loginError}</AlertDescription>
                </Alert>
              )}
              <Button type="submit" className="w-full">登录</Button>
            </form>
            <p className="text-sm text-muted-foreground text-center mt-4">
              默认账号: admin / 123456
            </p>
          </CardContent>
        </Card>
      </div>
    )
  }

  // 主界面布局
  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部导航 */}
      <header className="bg-white border-b shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Train className="h-8 w-8 text-primary" />
            <h1 className="text-xl font-bold">限高架智能管家</h1>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">欢迎, {user?.username}</span>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />退出
            </Button>
          </div>
        </div>
      </header>

      {/* 内容区域 */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* 台账列表页 */}
        {currentView === 'list' && (
          <div className="space-y-6">
            {/* 操作栏 */}
            <div className="flex flex-wrap items-center gap-4">
              <Button onClick={() => setCurrentView('add')}>
                <Plus className="h-4 w-4 mr-2" />新增桥涵
              </Button>
              <Button variant="outline" onClick={() => setCurrentView('import')}>
                <Upload className="h-4 w-4 mr-2" />数据导入
              </Button>
              <Button variant="outline" onClick={() => setCurrentView('alerts')}>
                <AlertTriangle className="h-4 w-4 mr-2" />预警管理
                {alerts.filter(a => a.status === 'pending').length > 0 && (
                  <Badge variant="destructive" className="ml-2">
                    {alerts.filter(a => a.status === 'pending').length}
                  </Badge>
                )}
              </Button>
            </div>

            {/* 筛选区 */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">筛选条件</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Label className="whitespace-nowrap">工区:</Label>
                    <Select value={filterWorkArea} onValueChange={setFilterWorkArea}>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="全部工区" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部工区</SelectItem>
                        {workAreas.map(area => (
                          <SelectItem key={area} value={area}>{area}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center gap-2">
                    <Label className="whitespace-nowrap">里程:</Label>
                    <Input
                      placeholder="搜索里程..."
                      value={filterMileage}
                      onChange={e => setFilterMileage(e.target.value)}
                      className="w-40"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Label className="whitespace-nowrap">状态:</Label>
                    <div className="flex gap-2">
                      {['red', 'yellow', 'green', 'blue'].map(status => (
                        <label key={status} className="flex items-center gap-1 cursor-pointer">
                          <Checkbox
                            checked={filterStatus.includes(status)}
                            onCheckedChange={() => toggleStatusFilter(status)}
                          />
                          <Badge className={statusColors[status]}>
                            {statusLabels[status]}
                          </Badge>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* 台账表格 */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <List className="h-5 w-5" />
                  台账列表
                  <Badge variant="secondary" className="ml-2">{bridges.length} 条记录</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {bridges.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    暂无数据，请导入Excel或手动添加
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-24">里程</TableHead>
                          <TableHead>桥涵名称</TableHead>
                          <TableHead className="w-24 text-center">下行状态</TableHead>
                          <TableHead className="w-24 text-center">上行状态</TableHead>
                          <TableHead className="w-20 text-right">下行净高</TableHead>
                          <TableHead className="w-20 text-right">上行净高</TableHead>
                          <TableHead>所属工区</TableHead>
                          <TableHead className="w-20 text-center">操作</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {bridges.map(bridge => (
                          <TableRow key={bridge.id}>
                            <TableCell className="font-medium text-primary cursor-pointer hover:underline"
                              onClick={() => handleViewDetail(bridge.id)}>
                              {bridge.mileage}
                            </TableCell>
                            <TableCell>{bridge.name}</TableCell>
                            <TableCell className="text-center">
                              {bridge.downPost ? (
                                <Badge className={statusColors[bridge.downPost.complianceStatus]}>
                                  {statusLabels[bridge.downPost.complianceStatus]}
                                </Badge>
                              ) : '--'}
                            </TableCell>
                            <TableCell className="text-center">
                              {bridge.upPost ? (
                                <Badge className={statusColors[bridge.upPost.complianceStatus]}>
                                  {statusLabels[bridge.upPost.complianceStatus]}
                                </Badge>
                              ) : '--'}
                            </TableCell>
                            <TableCell className="text-right">
                              {bridge.downPost ? `${bridge.downPost.height.toFixed(2)}m` : '--'}
                            </TableCell>
                            <TableCell className="text-right">
                              {bridge.upPost ? `${bridge.upPost.height.toFixed(2)}m` : '--'}
                            </TableCell>
                            <TableCell>{bridge.workArea}</TableCell>
                            <TableCell className="text-center">
                              <Button size="sm" variant="outline" 
                                onClick={() => handleViewDetail(bridge.id)}>
                                详情
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* 状态说明 */}
            <Card>
              <CardContent className="py-4">
                <div className="flex flex-wrap gap-6 text-sm">
                  <div className="flex items-center gap-2">
                    <Badge className="bg-red-500 text-white">严重隐患</Badge>
                    <span className="text-muted-foreground">限高架净高 ≥ 桥涵净高</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-yellow-500 text-white">余量不足</Badge>
                    <span className="text-muted-foreground">余量 &lt; 0.02m</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-green-500 text-white">符合规范</Badge>
                    <span className="text-muted-foreground">0.02m ≤ 余量 ≤ 0.10m</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-blue-500 text-white">限高过严</Badge>
                    <span className="text-muted-foreground">余量 &gt; 0.10m</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* 详情页 */}
        {currentView === 'detail' && selectedBridge && (
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <Button variant="outline" onClick={() => setCurrentView('list')}>
                <ChevronLeft className="h-4 w-4 mr-2" />返回列表
              </Button>
              <h2 className="text-xl font-bold">{selectedBridge.name}</h2>
              <Badge variant="outline">{selectedBridge.mileage}</Badge>
            </div>

            {/* 基本信息 */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">桥涵基本信息</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-6 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">桥涵净高:</span>
                    <span className="ml-2 font-medium">{selectedBridge.height.toFixed(2)}m</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">道路等级:</span>
                    <span className="ml-2 font-medium">{selectedBridge.roadLevel}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">所属工区:</span>
                    <span className="ml-2 font-medium">{selectedBridge.workArea}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">测量日期:</span>
                    <span className="ml-2 font-medium">{selectedBridge.measureDate || '--'}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">建议净高:</span>
                    <span className="ml-2 font-medium text-primary">
                      {getRecommendedHeight(selectedBridge.height).toFixed(2)}m
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* 上下行限高架 */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* 下行 */}
              <Card className={selectedBridge.downPost ? 
                (selectedBridge.downPost.complianceStatus === 'red' ? 'border-red-500 border-2' :
                 selectedBridge.downPost.complianceStatus === 'yellow' ? 'border-yellow-500 border-2' : '') : ''}>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <span>下行（公路侧）</span>
                    {selectedBridge.downPost && (
                      <Badge className={statusColors[selectedBridge.downPost.complianceStatus]}>
                        {statusLabels[selectedBridge.downPost.complianceStatus]}
                      </Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selectedBridge.downPost ? (
                    <>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div><span className="text-muted-foreground">限高架净高:</span> <b>{selectedBridge.downPost.height.toFixed(2)}m</b></div>
                        <div><span className="text-muted-foreground">结构形式:</span> {selectedBridge.downPost.structureType || '--'}</div>
                        <div><span className="text-muted-foreground">安装日期:</span> {selectedBridge.downPost.installDate || '--'}</div>
                        <div><span className="text-muted-foreground">最近巡检:</span> {selectedBridge.downPost.lastInspect || '--'}</div>
                        <div><span className="text-muted-foreground">传感器:</span> {selectedBridge.downPost.hasSensor ? '有' : '无'}</div>
                        <div><span className="text-muted-foreground">余量:</span> <b>{(selectedBridge.height - selectedBridge.downPost.height).toFixed(2)}m</b></div>
                      </div>
                      
                      {/* 状态说明卡片 */}
                      <div className={`p-4 rounded-lg ${
                        selectedBridge.downPost.complianceStatus === 'red' ? 'bg-red-50' :
                        selectedBridge.downPost.complianceStatus === 'yellow' ? 'bg-yellow-50' :
                        selectedBridge.downPost.complianceStatus === 'green' ? 'bg-green-50' : 'bg-blue-50'
                      }`}>
                        <div className="flex items-start gap-2">
                          {selectedBridge.downPost.complianceStatus === 'red' && <XCircle className="h-5 w-5 text-red-500 mt-0.5" />}
                          {selectedBridge.downPost.complianceStatus === 'yellow' && <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5" />}
                          {selectedBridge.downPost.complianceStatus === 'green' && <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />}
                          {selectedBridge.downPost.complianceStatus === 'blue' && <Info className="h-5 w-5 text-blue-500 mt-0.5" />}
                          <div>
                            <div className="font-medium">
                              {selectedBridge.downPost.complianceStatus === 'red' && '存在严重安全隐患'}
                              {selectedBridge.downPost.complianceStatus === 'yellow' && '安全余量不足'}
                              {selectedBridge.downPost.complianceStatus === 'green' && '符合TG/GW 212-2017规范'}
                              {selectedBridge.downPost.complianceStatus === 'blue' && '限高设置过严'}
                            </div>
                            <div className="text-sm text-muted-foreground mt-1">
                              建议限高架净高: <b className="text-primary">{getRecommendedHeight(selectedBridge.height).toFixed(2)}m</b>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* 视频播放 */}
                      {selectedBridge.downPost.videoUrl && (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm font-medium">
                            <Video className="h-4 w-4" /> 视频监控
                          </div>
                          {['.mp4', '.webm', '.ogg'].some(ext => 
                            selectedBridge.downPost!.videoUrl!.toLowerCase().endsWith(ext)
                          ) ? (
                            <video 
                              controls 
                              className="w-full rounded-lg border"
                              src={selectedBridge.downPost.videoUrl}
                            />
                          ) : (
                            <a 
                              href={selectedBridge.downPost.videoUrl} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-primary hover:underline text-sm flex items-center gap-1"
                            >
                              <Video className="h-4 w-4" /> 点击打开视频监控
                            </a>
                          )}
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="text-muted-foreground text-center py-4">暂无下行限高架数据</div>
                  )}
                </CardContent>
              </Card>

              {/* 上行 */}
              <Card className={selectedBridge.upPost ? 
                (selectedBridge.upPost.complianceStatus === 'red' ? 'border-red-500 border-2' :
                 selectedBridge.upPost.complianceStatus === 'yellow' ? 'border-yellow-500 border-2' : '') : ''}>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <span>上行（铁路侧）</span>
                    {selectedBridge.upPost ? (
                      <Badge className={statusColors[selectedBridge.upPost.complianceStatus]}>
                        {statusLabels[selectedBridge.upPost.complianceStatus]}
                      </Badge>
                    ) : (
                      <Badge variant="secondary">暂无数据</Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selectedBridge.upPost ? (
                    <>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div><span className="text-muted-foreground">限高架净高:</span> <b>{selectedBridge.upPost.height.toFixed(2)}m</b></div>
                        <div><span className="text-muted-foreground">结构形式:</span> {selectedBridge.upPost.structureType || '--'}</div>
                        <div><span className="text-muted-foreground">安装日期:</span> {selectedBridge.upPost.installDate || '--'}</div>
                        <div><span className="text-muted-foreground">最近巡检:</span> {selectedBridge.upPost.lastInspect || '--'}</div>
                        <div><span className="text-muted-foreground">传感器:</span> {selectedBridge.upPost.hasSensor ? '有' : '无'}</div>
                        <div><span className="text-muted-foreground">余量:</span> <b>{(selectedBridge.height - selectedBridge.upPost.height).toFixed(2)}m</b></div>
                      </div>
                      
                      <div className={`p-4 rounded-lg ${
                        selectedBridge.upPost.complianceStatus === 'red' ? 'bg-red-50' :
                        selectedBridge.upPost.complianceStatus === 'yellow' ? 'bg-yellow-50' :
                        selectedBridge.upPost.complianceStatus === 'green' ? 'bg-green-50' : 'bg-blue-50'
                      }`}>
                        <div className="flex items-start gap-2">
                          {selectedBridge.upPost.complianceStatus === 'red' && <XCircle className="h-5 w-5 text-red-500 mt-0.5" />}
                          {selectedBridge.upPost.complianceStatus === 'yellow' && <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5" />}
                          {selectedBridge.upPost.complianceStatus === 'green' && <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />}
                          {selectedBridge.upPost.complianceStatus === 'blue' && <Info className="h-5 w-5 text-blue-500 mt-0.5" />}
                          <div>
                            <div className="font-medium">
                              {selectedBridge.upPost.complianceStatus === 'red' && '存在严重安全隐患'}
                              {selectedBridge.upPost.complianceStatus === 'yellow' && '安全余量不足'}
                              {selectedBridge.upPost.complianceStatus === 'green' && '符合TG/GW 212-2017规范'}
                              {selectedBridge.upPost.complianceStatus === 'blue' && '限高设置过严'}
                            </div>
                            <div className="text-sm text-muted-foreground mt-1">
                              建议限高架净高: <b className="text-primary">{getRecommendedHeight(selectedBridge.height).toFixed(2)}m</b>
                            </div>
                          </div>
                        </div>
                      </div>

                      {selectedBridge.upPost.videoUrl && (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm font-medium">
                            <Video className="h-4 w-4" /> 视频监控
                          </div>
                          {['.mp4', '.webm', '.ogg'].some(ext => 
                            selectedBridge.upPost!.videoUrl!.toLowerCase().endsWith(ext)
                          ) ? (
                            <video 
                              controls 
                              className="w-full rounded-lg border"
                              src={selectedBridge.upPost.videoUrl}
                            />
                          ) : (
                            <a 
                              href={selectedBridge.upPost.videoUrl} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-primary hover:underline text-sm flex items-center gap-1"
                            >
                              <Video className="h-4 w-4" /> 点击打开视频监控
                            </a>
                          )}
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="text-muted-foreground text-center py-4">暂无上行限高架数据</div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* 操作按钮 */}
            <div className="flex gap-4">
              <Button onClick={handleRecheck}>
                <RefreshCw className="h-4 w-4 mr-2" />重新校验
              </Button>
            </div>

            {/* 历史预警 */}
            {selectedBridge.alerts && selectedBridge.alerts.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5" /> 历史预警
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>预警等级</TableHead>
                        <TableHead>原因</TableHead>
                        <TableHead>创建时间</TableHead>
                        <TableHead>状态</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedBridge.alerts.map((alert: AlertItem) => (
                        <TableRow key={alert.id}>
                          <TableCell>
                            <Badge className={statusColors[alert.level]}>
                              {alert.level === 'red' ? '严重' : '警告'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm">{alert.reason}</TableCell>
                          <TableCell className="text-sm">{alert.createTime}</TableCell>
                          <TableCell>
                            <Badge variant={alert.status === 'done' ? 'secondary' : 'destructive'}>
                              {alert.status === 'pending' ? '待处理' : 
                               alert.status === 'processing' ? '处理中' : '已闭环'}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* 导入页面 */}
        {currentView === 'import' && (
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <Button variant="outline" onClick={() => setCurrentView('list')}>
                <ChevronLeft className="h-4 w-4 mr-2" />返回列表
              </Button>
              <h2 className="text-xl font-bold">数据导入</h2>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileSpreadsheet className="h-5 w-5" /> Excel导入
                </CardTitle>
                <CardDescription>
                  上传Excel文件批量导入限高架台账数据
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center gap-4">
                  <Button variant="outline" onClick={downloadTemplate}>
                    <Download className="h-4 w-4 mr-2" />下载模板
                  </Button>
                  <label>
                    <Input
                      type="file"
                      accept=".xlsx,.xls"
                      onChange={handleImport}
                      className="hidden"
                    />
                    <Button asChild>
                      <span className="cursor-pointer">
                        <Upload className="h-4 w-4 mr-2" />选择文件
                      </span>
                    </Button>
                  </label>
                </div>

                {importResult && (
                  <Alert variant={importResult.failCount > 0 ? 'destructive' : 'default'}>
                    <CheckCircle className="h-4 w-4" />
                    <AlertTitle>{importResult.message}</AlertTitle>
                    <AlertDescription>
                      <div className="mt-2">
                        成功: {importResult.successCount} 条，失败: {importResult.failCount} 条
                      </div>
                      {importResult.errors && importResult.errors.length > 0 && (
                        <div className="mt-4">
                          <div className="font-medium mb-2">错误详情:</div>
                          <div className="max-h-60 overflow-y-auto space-y-1">
                            {importResult.errors.map((err, idx) => (
                              <div key={idx} className="text-sm">
                                第{err.row}行: {err.reason}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">模板说明</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>字段名</TableHead>
                      <TableHead>说明</TableHead>
                      <TableHead>是否必填</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow><TableCell>桥涵名称</TableCell><TableCell>桥涵的名称</TableCell><TableCell>是</TableCell></TableRow>
                    <TableRow><TableCell>里程</TableCell><TableCell>如 K12+345</TableCell><TableCell>是</TableCell></TableRow>
                    <TableRow><TableCell>桥涵净高</TableCell><TableCell>单位：米，保留两位小数</TableCell><TableCell>是</TableCell></TableRow>
                    <TableRow><TableCell>下行净高</TableCell><TableCell>单位：米</TableCell><TableCell>是</TableCell></TableRow>
                    <TableRow><TableCell>上行净高</TableCell><TableCell>单位：米，若无则留空</TableCell><TableCell>否</TableCell></TableRow>
                    <TableRow><TableCell>道路等级</TableCell><TableCell>国道/省道/县道/城市道路/乡村道路</TableCell><TableCell>是</TableCell></TableRow>
                    <TableRow><TableCell>所属工区</TableCell><TableCell>如"石家庄车间"</TableCell><TableCell>是</TableCell></TableRow>
                    <TableRow><TableCell>结构形式</TableCell><TableCell>门式/三角架式/桁架式</TableCell><TableCell>否</TableCell></TableRow>
                    <TableRow><TableCell>安装日期</TableCell><TableCell>YYYY-MM-DD</TableCell><TableCell>否</TableCell></TableRow>
                    <TableRow><TableCell>有无传感器</TableCell><TableCell>0表示无，1表示有</TableCell><TableCell>否</TableCell></TableRow>
                    <TableRow><TableCell>视频地址</TableCell><TableCell>视频URL或监控流地址</TableCell><TableCell>否</TableCell></TableRow>
                    <TableRow><TableCell>测量日期</TableCell><TableCell>YYYY-MM-DD，默认导入当天</TableCell><TableCell>否</TableCell></TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        )}

        {/* 预警管理页面 */}
        {currentView === 'alerts' && (
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <Button variant="outline" onClick={() => setCurrentView('list')}>
                <ChevronLeft className="h-4 w-4 mr-2" />返回列表
              </Button>
              <h2 className="text-xl font-bold">预警管理</h2>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" /> 预警列表
                </CardTitle>
              </CardHeader>
              <CardContent>
                {alerts.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">暂无预警记录</div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>里程</TableHead>
                        <TableHead>桥涵名称</TableHead>
                        <TableHead>方向</TableHead>
                        <TableHead>等级</TableHead>
                        <TableHead>原因</TableHead>
                        <TableHead>创建时间</TableHead>
                        <TableHead>状态</TableHead>
                        <TableHead>操作</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {alerts.map(alert => (
                        <TableRow key={alert.id}>
                          <TableCell className="font-medium">{alert.bridge.mileage}</TableCell>
                          <TableCell>{alert.bridge.name}</TableCell>
                          <TableCell>{alert.post.direction === 'down' ? '下行' : '上行'}</TableCell>
                          <TableCell>
                            <Badge className={statusColors[alert.level]}>
                              {alert.level === 'red' ? '严重' : '警告'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm max-w-xs truncate">{alert.reason}</TableCell>
                          <TableCell className="text-sm">{alert.createTime}</TableCell>
                          <TableCell>
                            <Badge variant={alert.status === 'done' ? 'secondary' : 'destructive'}>
                              {alert.status === 'pending' ? '待处理' : 
                               alert.status === 'processing' ? '处理中' : '已闭环'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {alert.status !== 'done' && (
                              <div className="flex gap-2">
                                {alert.status === 'pending' && (
                                  <Button size="sm" variant="outline"
                                    onClick={() => handleAlertStatus(alert.id, 'processing')}>
                                    处理
                                  </Button>
                                )}
                                <Button size="sm" 
                                  onClick={() => handleAlertStatus(alert.id, 'done')}>
                                  闭环
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* 新增桥涵页面 */}
        {currentView === 'add' && (
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <Button variant="outline" onClick={() => setCurrentView('list')}>
                <ChevronLeft className="h-4 w-4 mr-2" />返回列表
              </Button>
              <h2 className="text-xl font-bold">新增桥涵</h2>
            </div>

            <form onSubmit={handleAddBridge}>
              <div className="grid gap-6">
                {/* 基本信息 */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">基本信息</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>桥涵名称 *</Label>
                        <Input value={formData.name} 
                          onChange={e => setFormData(prev => ({ ...prev, name: e.target.value }))}
                          required />
                      </div>
                      <div className="space-y-2">
                        <Label>里程 *</Label>
                        <Input value={formData.mileage} 
                          onChange={e => setFormData(prev => ({ ...prev, mileage: e.target.value }))}
                          placeholder="K12+345" required />
                      </div>
                      <div className="space-y-2">
                        <Label>桥涵净高(米) *</Label>
                        <Input type="number" step="0.01" value={formData.height} 
                          onChange={e => setFormData(prev => ({ ...prev, height: e.target.value }))}
                          required />
                      </div>
                      <div className="space-y-2">
                        <Label>道路等级 *</Label>
                        <Select value={formData.roadLevel} 
                          onValueChange={v => setFormData(prev => ({ ...prev, roadLevel: v }))}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {Object.keys(roadLevelLabels).map(level => (
                              <SelectItem key={level} value={level}>{level}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>所属工区 *</Label>
                        <Input value={formData.workArea} 
                          onChange={e => setFormData(prev => ({ ...prev, workArea: e.target.value }))}
                          required />
                      </div>
                      <div className="space-y-2">
                        <Label>测量日期</Label>
                        <Input type="date" value={formData.measureDate} 
                          onChange={e => setFormData(prev => ({ ...prev, measureDate: e.target.value }))} />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* 下行限高架 */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">下行限高架（公路侧）</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>限高架净高(米) *</Label>
                        <Input type="number" step="0.01" value={formData.downHeight} 
                          onChange={e => setFormData(prev => ({ ...prev, downHeight: e.target.value }))}
                          required />
                        {formData.height && (
                          <p className="text-sm text-muted-foreground">
                            建议: {getRecommendedHeight(parseFloat(formData.height)).toFixed(2)}m
                          </p>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label>结构形式</Label>
                        <Select value={formData.downStructureType} 
                          onValueChange={v => setFormData(prev => ({ ...prev, downStructureType: v }))}>
                          <SelectTrigger><SelectValue placeholder="选择结构形式" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="门式">门式</SelectItem>
                            <SelectItem value="三角架式">三角架式</SelectItem>
                            <SelectItem value="桁架式">桁架式</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>安装日期</Label>
                        <Input type="date" value={formData.downInstallDate} 
                          onChange={e => setFormData(prev => ({ ...prev, downInstallDate: e.target.value }))} />
                      </div>
                      <div className="space-y-2">
                        <Label>视频地址</Label>
                        <Input value={formData.downVideoUrl} 
                          onChange={e => setFormData(prev => ({ ...prev, downVideoUrl: e.target.value }))}
                          placeholder="视频URL" />
                      </div>
                      <div className="flex items-center gap-2 pt-6">
                        <Checkbox id="downSensor" checked={formData.downHasSensor}
                          onCheckedChange={v => setFormData(prev => ({ ...prev, downHasSensor: !!v }))} />
                        <Label htmlFor="downSensor">有传感器</Label>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* 上行限高架 */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">上行限高架（铁路侧）- 可选</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>限高架净高(米)</Label>
                        <Input type="number" step="0.01" value={formData.upHeight} 
                          onChange={e => setFormData(prev => ({ ...prev, upHeight: e.target.value }))} />
                        {formData.height && (
                          <p className="text-sm text-muted-foreground">
                            建议: {getRecommendedHeight(parseFloat(formData.height)).toFixed(2)}m
                          </p>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label>结构形式</Label>
                        <Select value={formData.upStructureType} 
                          onValueChange={v => setFormData(prev => ({ ...prev, upStructureType: v }))}>
                          <SelectTrigger><SelectValue placeholder="选择结构形式" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="门式">门式</SelectItem>
                            <SelectItem value="三角架式">三角架式</SelectItem>
                            <SelectItem value="桁架式">桁架式</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>安装日期</Label>
                        <Input type="date" value={formData.upInstallDate} 
                          onChange={e => setFormData(prev => ({ ...prev, upInstallDate: e.target.value }))} />
                      </div>
                      <div className="space-y-2">
                        <Label>视频地址</Label>
                        <Input value={formData.upVideoUrl} 
                          onChange={e => setFormData(prev => ({ ...prev, upVideoUrl: e.target.value }))}
                          placeholder="视频URL" />
                      </div>
                      <div className="flex items-center gap-2 pt-6">
                        <Checkbox id="upSensor" checked={formData.upHasSensor}
                          onCheckedChange={v => setFormData(prev => ({ ...prev, upHasSensor: !!v }))} />
                        <Label htmlFor="upSensor">有传感器</Label>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="flex gap-4">
                  <Button type="submit">保存</Button>
                  <Button type="button" variant="outline" onClick={() => setCurrentView('list')}>取消</Button>
                </div>
              </div>
            </form>
          </div>
        )}
      </main>

      {/* 底部 */}
      <footer className="bg-white border-t mt-auto py-4">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-muted-foreground">
          限高架智能管家 - 铁路桥涵限高防护架数字台账与预警系统 | 依据 TG/GW 212-2017 规范
        </div>
      </footer>
    </div>
  )
}
