import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'

export async function GET() {
  try {
    const cookieStore = await cookies()
    const sessionCookie = cookieStore.get('session')

    if (!sessionCookie) {
      return NextResponse.json({ user: null }, { status: 401 })
    }

    const session = JSON.parse(sessionCookie.value)
    const user = await db.user.findUnique({
      where: { id: session.userId }
    })

    if (!user) {
      return NextResponse.json({ user: null }, { status: 401 })
    }

    return NextResponse.json({ 
      user: { id: user.id, username: user.username, role: user.role } 
    })
  } catch (error) {
    console.error('获取用户信息失败:', error)
    return NextResponse.json({ user: null }, { status: 401 })
  }
}
