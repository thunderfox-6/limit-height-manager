import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { username, password } = body

    if (!username || !password) {
      return NextResponse.json({ error: '用户名和密码不能为空' }, { status: 400 })
    }

    // 查询用户
    const user = await db.user.findUnique({
      where: { username }
    })

    if (!user || user.password !== password) {
      return NextResponse.json({ error: '用户名或密码错误' }, { status: 401 })
    }

    // 设置session cookie（简化版，使用用户ID作为token）
    const cookieStore = await cookies()
    cookieStore.set('session', JSON.stringify({ userId: user.id, username: user.username }), {
      httpOnly: true,
      secure: false, // 内网环境，不需要HTTPS
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7 // 7天
    })

    return NextResponse.json({ 
      message: '登录成功', 
      user: { id: user.id, username: user.username, role: user.role } 
    })
  } catch (error) {
    console.error('登录失败:', error)
    return NextResponse.json({ error: '登录失败' }, { status: 500 })
  }
}
