import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    // 检查是否已存在管理员用户
    const existingAdmin = await db.user.findUnique({
      where: { username: 'admin' }
    })

    if (existingAdmin) {
      return NextResponse.json({ message: '数据库已初始化', exists: true })
    }

    // 创建默认管理员账号
    await db.user.create({
      data: {
        username: 'admin',
        password: '123456', // 简单密码，实际应用应加密
        role: 'admin'
      }
    })

    return NextResponse.json({ message: '数据库初始化成功，默认管理员账号已创建', exists: false })
  } catch (error) {
    console.error('初始化数据库失败:', error)
    return NextResponse.json({ error: '初始化失败' }, { status: 500 })
  }
}
