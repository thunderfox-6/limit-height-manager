import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'

// 验证用户登录
async function checkAuth() {
  const cookieStore = await cookies()
  const sessionCookie = cookieStore.get('session')
  
  if (!sessionCookie) {
    return null
  }
  
  try {
    const session = JSON.parse(sessionCookie.value)
    return session
  } catch {
    return null
  }
}

// GET - 获取预警列表
export async function GET(request: NextRequest) {
  const user = await checkAuth()
  if (!user) {
    return NextResponse.json({ error: '未授权' }, { status: 401 })
  }

  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const level = searchParams.get('level')

    const where: Record<string, unknown> = {}
    if (status && status !== 'all') {
      where.status = status
    }
    if (level && level !== 'all') {
      where.level = level
    }

    const alerts = await db.alert.findMany({
      where,
      include: {
        bridge: {
          select: {
            name: true,
            mileage: true,
            height: true
          }
        },
        post: {
          select: {
            direction: true,
            height: true
          }
        }
      },
      orderBy: { createTime: 'desc' },
      take: 100
    })

    return NextResponse.json({ alerts })
  } catch (error) {
    console.error('获取预警列表失败:', error)
    return NextResponse.json({ error: '获取失败' }, { status: 500 })
  }
}

// PUT - 更新预警状态（闭环处理）
export async function PUT(request: NextRequest) {
  const user = await checkAuth()
  if (!user) {
    return NextResponse.json({ error: '未授权' }, { status: 401 })
  }

  try {
    const body = await request.json()
    const { id, status } = body

    const alert = await db.alert.update({
      where: { id },
      data: {
        status,
        closeTime: status === 'done' 
          ? new Date().toISOString().replace('T', ' ').slice(0, 19) 
          : null
      }
    })

    return NextResponse.json({ message: '更新成功', alert })
  } catch (error) {
    console.error('更新预警失败:', error)
    return NextResponse.json({ error: '更新失败' }, { status: 500 })
  }
}
