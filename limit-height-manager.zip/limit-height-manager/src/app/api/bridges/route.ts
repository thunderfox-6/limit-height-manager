import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'

// 计算合规状态
function calculateComplianceStatus(bridgeHeight: number, postHeight: number): string {
  const diff = bridgeHeight - postHeight
  
  if (postHeight >= bridgeHeight) {
    return 'red' // 限高架净高 >= 桥涵净高（严重隐患）
  } else if (diff < 0.02) {
    return 'yellow' // 余量不足
  } else if (diff <= 0.10) {
    return 'green' // 符合规范
  } else {
    return 'blue' // 限高过严
  }
}

// 验证用户登录
async function checkAuth() {
  const cookieStore = await cookies()
  const sessionCookie = cookieStore.get('session')
  
  if (!sessionCookie) {
    return null
  }
  
  try {
    const session = JSON.parse(sessionCookie.value)
    return session
  } catch {
    return null
  }
}

// GET - 获取桥涵列表
export async function GET(request: NextRequest) {
  const user = await checkAuth()
  if (!user) {
    return NextResponse.json({ error: '未授权' }, { status: 401 })
  }

  try {
    const { searchParams } = new URL(request.url)
    const workArea = searchParams.get('workArea')
    const status = searchParams.get('status')
    const mileage = searchParams.get('mileage')

    // 构建查询条件
    const where: Record<string, unknown> = {}
    
    if (workArea && workArea !== 'all') {
      where.workArea = workArea
    }

    if (mileage) {
      where.mileage = { contains: mileage }
    }

    // 查询桥涵及其限高架
    const bridges = await db.bridge.findMany({
      where,
      include: {
        limitPosts: true
      },
      orderBy: { mileage: 'asc' }
    })

    // 如果有状态筛选，需要在应用层过滤
    let result = bridges.map(bridge => {
      const downPost = bridge.limitPosts.find(p => p.direction === 'down')
      const upPost = bridge.limitPosts.find(p => p.direction === 'up')
      
      return {
        id: bridge.id,
        name: bridge.name,
        mileage: bridge.mileage,
        height: bridge.height,
        roadLevel: bridge.roadLevel,
        workArea: bridge.workArea,
        measureDate: bridge.measureDate,
        downPost: downPost || null,
        upPost: upPost || null
      }
    })

    // 状态筛选
    if (status) {
      const statusList = status.split(',')
      result = result.filter(bridge => {
        const downStatus = bridge.downPost?.complianceStatus
        const upStatus = bridge.upPost?.complianceStatus
        return statusList.includes(downStatus) || (upStatus && statusList.includes(upStatus))
      })
    }

    // 获取所有工区列表（用于筛选）
    const allBridges = await db.bridge.findMany({
      select: { workArea: true }
    })
    const workAreas = [...new Set(allBridges.map(b => b.workArea))]

    return NextResponse.json({ bridges: result, workAreas })
  } catch (error) {
    console.error('获取桥涵列表失败:', error)
    return NextResponse.json({ error: '获取列表失败' }, { status: 500 })
  }
}

// POST - 创建桥涵及限高架
export async function POST(request: NextRequest) {
  const user = await checkAuth()
  if (!user) {
    return NextResponse.json({ error: '未授权' }, { status: 401 })
  }

  try {
    const body = await request.json()
    const { 
      name, mileage, height, roadLevel, workArea, measureDate,
      downHeight, downStructureType, downInstallDate, downHasSensor, downVideoUrl,
      upHeight, upStructureType, upInstallDate, upHasSensor, upVideoUrl
    } = body

    // 验证必填字段
    if (!name || !mileage || height === undefined || !roadLevel || !workArea) {
      return NextResponse.json({ error: '缺少必填字段' }, { status: 400 })
    }

    // 创建桥涵
    const bridge = await db.bridge.create({
      data: {
        name,
        mileage,
        height: parseFloat(height),
        roadLevel,
        workArea,
        measureDate: measureDate || new Date().toISOString().split('T')[0]
      }
    })

    // 创建下行限高架
    if (downHeight !== undefined && downHeight !== null && downHeight !== '') {
      const downStatus = calculateComplianceStatus(parseFloat(height), parseFloat(downHeight))
      await db.limitPost.create({
        data: {
          bridgeId: bridge.id,
          direction: 'down',
          height: parseFloat(downHeight),
          structureType: downStructureType || null,
          installDate: downInstallDate || null,
          hasSensor: downHasSensor ? 1 : 0,
          videoUrl: downVideoUrl || null,
          complianceStatus: downStatus
        }
      })
    }

    // 创建上行限高架（可选）
    if (upHeight !== undefined && upHeight !== null && upHeight !== '') {
      const upStatus = calculateComplianceStatus(parseFloat(height), parseFloat(upHeight))
      await db.limitPost.create({
        data: {
          bridgeId: bridge.id,
          direction: 'up',
          height: parseFloat(upHeight),
          structureType: upStructureType || null,
          installDate: upInstallDate || null,
          hasSensor: upHasSensor ? 1 : 0,
          videoUrl: upVideoUrl || null,
          complianceStatus: upStatus
        }
      })
    }

    return NextResponse.json({ message: '创建成功', bridge })
  } catch (error) {
    console.error('创建桥涵失败:', error)
    return NextResponse.json({ error: '创建失败' }, { status: 500 })
  }
}
