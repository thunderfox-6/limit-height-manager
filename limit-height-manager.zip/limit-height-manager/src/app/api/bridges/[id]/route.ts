import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'

// 计算合规状态
function calculateComplianceStatus(bridgeHeight: number, postHeight: number): string {
  const diff = bridgeHeight - postHeight
  
  if (postHeight >= bridgeHeight) {
    return 'red' // 限高架净高 >= 桥涵净高（严重隐患）
  } else if (diff < 0.02) {
    return 'yellow' // 余量不足
  } else if (diff <= 0.10) {
    return 'green' // 符合规范
  } else {
    return 'blue' // 限高过严
  }
}

// 验证用户登录
async function checkAuth() {
  const cookieStore = await cookies()
  const sessionCookie = cookieStore.get('session')
  
  if (!sessionCookie) {
    return null
  }
  
  try {
    const session = JSON.parse(sessionCookie.value)
    return session
  } catch {
    return null
  }
}

// GET - 获取桥涵详情
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await checkAuth()
  if (!user) {
    return NextResponse.json({ error: '未授权' }, { status: 401 })
  }

  try {
    const { id } = await params
    
    const bridge = await db.bridge.findUnique({
      where: { id },
      include: {
        limitPosts: true,
        alerts: {
          orderBy: { createTime: 'desc' },
          take: 10
        }
      }
    })

    if (!bridge) {
      return NextResponse.json({ error: '桥涵不存在' }, { status: 404 })
    }

    const downPost = bridge.limitPosts.find(p => p.direction === 'down')
    const upPost = bridge.limitPosts.find(p => p.direction === 'up')

    return NextResponse.json({ 
      bridge: {
        ...bridge,
        downPost,
        upPost
      }
    })
  } catch (error) {
    console.error('获取桥涵详情失败:', error)
    return NextResponse.json({ error: '获取详情失败' }, { status: 500 })
  }
}

// PUT - 更新桥涵及限高架
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await checkAuth()
  if (!user) {
    return NextResponse.json({ error: '未授权' }, { status: 401 })
  }

  try {
    const { id } = await params
    const body = await request.json()
    const { 
      name, mileage, height, roadLevel, workArea, measureDate,
      downPost, upPost
    } = body

    // 更新桥涵
    const bridge = await db.bridge.update({
      where: { id },
      data: {
        name,
        mileage,
        height: parseFloat(height),
        roadLevel,
        workArea,
        measureDate: measureDate || null
      }
    })

    // 更新或创建下行限高架
    if (downPost) {
      const downStatus = calculateComplianceStatus(parseFloat(height), parseFloat(downPost.height))
      if (downPost.id) {
        await db.limitPost.update({
          where: { id: downPost.id },
          data: {
            height: parseFloat(downPost.height),
            structureType: downPost.structureType || null,
            installDate: downPost.installDate || null,
            lastInspect: downPost.lastInspect || null,
            hasSensor: downPost.hasSensor ? 1 : 0,
            videoUrl: downPost.videoUrl || null,
            complianceStatus: downStatus
          }
        })
      } else {
        await db.limitPost.create({
          data: {
            bridgeId: bridge.id,
            direction: 'down',
            height: parseFloat(downPost.height),
            structureType: downPost.structureType || null,
            installDate: downPost.installDate || null,
            lastInspect: downPost.lastInspect || null,
            hasSensor: downPost.hasSensor ? 1 : 0,
            videoUrl: downPost.videoUrl || null,
            complianceStatus: downStatus
          }
        })
      }
    }

    // 更新或创建上行限高架
    if (upPost) {
      const upStatus = calculateComplianceStatus(parseFloat(height), parseFloat(upPost.height))
      if (upPost.id) {
        await db.limitPost.update({
          where: { id: upPost.id },
          data: {
            height: parseFloat(upPost.height),
            structureType: upPost.structureType || null,
            installDate: upPost.installDate || null,
            lastInspect: upPost.lastInspect || null,
            hasSensor: upPost.hasSensor ? 1 : 0,
            videoUrl: upPost.videoUrl || null,
            complianceStatus: upStatus
          }
        })
      } else {
        await db.limitPost.create({
          data: {
            bridgeId: bridge.id,
            direction: 'up',
            height: parseFloat(upPost.height),
            structureType: upPost.structureType || null,
            installDate: upPost.installDate || null,
            lastInspect: upPost.lastInspect || null,
            hasSensor: upPost.hasSensor ? 1 : 0,
            videoUrl: upPost.videoUrl || null,
            complianceStatus: upStatus
          }
        })
      }
    }

    return NextResponse.json({ message: '更新成功', bridge })
  } catch (error) {
    console.error('更新桥涵失败:', error)
    return NextResponse.json({ error: '更新失败' }, { status: 500 })
  }
}

// DELETE - 删除桥涵
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await checkAuth()
  if (!user) {
    return NextResponse.json({ error: '未授权' }, { status: 401 })
  }

  try {
    const { id } = await params
    
    // 删除关联的限高架和预警（级联删除）
    await db.bridge.delete({
      where: { id }
    })

    return NextResponse.json({ message: '删除成功' })
  } catch (error) {
    console.error('删除桥涵失败:', error)
    return NextResponse.json({ error: '删除失败' }, { status: 500 })
  }
}
