import { db } from '@/lib/db'
import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'

// 计算合规状态
function calculateComplianceStatus(bridgeHeight: number, postHeight: number): string {
  const diff = bridgeHeight - postHeight
  
  if (postHeight >= bridgeHeight) {
    return 'red' // 限高架净高 >= 桥涵净高（严重隐患）
  } else if (diff < 0.02) {
    return 'yellow' // 余量不足
  } else if (diff <= 0.10) {
    return 'green' // 符合规范
  } else {
    return 'blue' // 限高过严
  }
}

// 验证用户登录
async function checkAuth() {
  const cookieStore = await cookies()
  const sessionCookie = cookieStore.get('session')
  
  if (!sessionCookie) {
    return null
  }
  
  try {
    const session = JSON.parse(sessionCookie.value)
    return session
  } catch {
    return null
  }
}

// 全量校验所有限高架
export async function POST() {
  const user = await checkAuth()
  if (!user) {
    return NextResponse.json({ error: '未授权' }, { status: 401 })
  }

  try {
    const bridges = await db.bridge.findMany({
      include: {
        limitPosts: true
      }
    })

    let updatedCount = 0
    let alertCount = 0

    for (const bridge of bridges) {
      for (const post of bridge.limitPosts) {
        const newStatus = calculateComplianceStatus(bridge.height, post.height)
        
        if (post.complianceStatus !== newStatus) {
          // 更新状态
          await db.limitPost.update({
            where: { id: post.id },
            data: { complianceStatus: newStatus }
          })
          updatedCount++

          // 如果变为红色或黄色，创建预警
          if ((newStatus === 'red' || newStatus === 'yellow') && 
              (post.complianceStatus === 'green' || post.complianceStatus === 'blue')) {
            const reason = newStatus === 'red' 
              ? `${post.direction === 'down' ? '下行' : '上行'}限高架净高(${post.height}m) >= 桥涵净高(${bridge.height}m)，存在严重安全隐患`
              : `${post.direction === 'down' ? '下行' : '上行'}桥涵净高(${bridge.height}m) - 限高架净高(${post.height}m) < 0.02m，余量不足`
            
            await db.alert.create({
              data: {
                postId: post.id,
                bridgeId: bridge.id,
                level: newStatus,
                reason,
                status: 'pending',
                createTime: new Date().toISOString().replace('T', ' ').slice(0, 19)
              }
            })
            alertCount++
          }
        }
      }
    }

    return NextResponse.json({
      message: '校验完成',
      updatedCount,
      alertCount,
      totalBridges: bridges.length
    })
  } catch (error) {
    console.error('全量校验失败:', error)
    return NextResponse.json({ error: '校验失败' }, { status: 500 })
  }
}
