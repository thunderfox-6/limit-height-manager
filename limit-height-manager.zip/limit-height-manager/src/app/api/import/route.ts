import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import * as XLSX from 'xlsx'

// 计算合规状态
function calculateComplianceStatus(bridgeHeight: number, postHeight: number): string {
  const diff = bridgeHeight - postHeight
  
  if (postHeight >= bridgeHeight) {
    return 'red' // 限高架净高 >= 桥涵净高（严重隐患）
  } else if (diff < 0.02) {
    return 'yellow' // 余量不足
  } else if (diff <= 0.10) {
    return 'green' // 符合规范
  } else {
    return 'blue' // 限高过严
  }
}

// 验证用户登录
async function checkAuth() {
  const cookieStore = await cookies()
  const sessionCookie = cookieStore.get('session')
  
  if (!sessionCookie) {
    return null
  }
  
  try {
    const session = JSON.parse(sessionCookie.value)
    return session
  } catch {
    return null
  }
}

export async function POST(request: NextRequest) {
  const user = await checkAuth()
  if (!user) {
    return NextResponse.json({ error: '未授权' }, { status: 401 })
  }

  try {
    const formData = await request.formData()
    const file = formData.get('file') as File

    if (!file) {
      return NextResponse.json({ error: '请上传文件' }, { status: 400 })
    }

    // 读取Excel文件
    const buffer = await file.arrayBuffer()
    const workbook = XLSX.read(buffer, { type: 'array' })
    const sheetName = workbook.SheetNames[0]
    const worksheet = workbook.Sheets[sheetName]
    const data = XLSX.utils.sheet_to_json<Record<string, unknown>>(worksheet)

    if (data.length === 0) {
      return NextResponse.json({ error: '文件无数据' }, { status: 400 })
    }

    const errors: { row: number; reason: string }[] = []
    let successCount = 0

    // 日期格式化
    const formatDate = (value: unknown): string | null => {
      if (!value) return null
      if (typeof value === 'string') {
        // 检查是否是日期字符串
        const dateMatch = value.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/)
        if (dateMatch) {
          return `${dateMatch[1]}-${dateMatch[2].padStart(2, '0')}-${dateMatch[3].padStart(2, '0')}`
        }
        return value
      }
      // Excel日期序列号处理
      if (typeof value === 'number') {
        const date = new Date((value - 25569) * 86400 * 1000)
        return date.toISOString().split('T')[0]
      }
      return null
    }

    // 解析净高数值
    const parseHeight = (value: unknown): number | null => {
      if (value === undefined || value === null || value === '') return null
      const num = parseFloat(String(value))
      return isNaN(num) ? null : num
    }

    // 处理每一行数据
    for (let i = 0; i < data.length; i++) {
      const row = data[i]
      const rowNum = i + 2 // Excel行号从2开始（第1行是标题）

      try {
        // 字段映射（支持多种可能的列名）
        const name = row['桥涵名称'] || row['名称'] as string
        const mileage = row['里程'] as string
        const bridgeHeight = parseHeight(row['桥涵净高'])
        const downHeight = parseHeight(row['下行净高'])
        const upHeight = parseHeight(row['上行净高'])
        const roadLevel = row['道路等级'] as string
        const workArea = row['所属工区'] as string
        const structureType = row['结构形式'] as string
        const installDate = formatDate(row['安装日期'])
        const hasSensor = row['有无传感器'] === 1 || row['有无传感器'] === '1' ? 1 : 0
        const videoUrl = row['视频地址'] as string || null
        const measureDate = formatDate(row['测量日期'])

        // 必填项校验
        if (!name) {
          errors.push({ row: rowNum, reason: '桥涵名称不能为空' })
          continue
        }
        if (!mileage) {
          errors.push({ row: rowNum, reason: '里程不能为空' })
          continue
        }
        if (bridgeHeight === null) {
          errors.push({ row: rowNum, reason: '桥涵净高不能为空或格式错误' })
          continue
        }
        if (downHeight === null) {
          errors.push({ row: rowNum, reason: '下行净高不能为空或格式错误' })
          continue
        }
        if (!roadLevel) {
          errors.push({ row: rowNum, reason: '道路等级不能为空' })
          continue
        }
        if (!workArea) {
          errors.push({ row: rowNum, reason: '所属工区不能为空' })
          continue
        }

        // 创建桥涵
        const bridge = await db.bridge.create({
          data: {
            name,
            mileage,
            height: bridgeHeight,
            roadLevel,
            workArea,
            measureDate: measureDate || new Date().toISOString().split('T')[0]
          }
        })

        // 创建下行限高架
        const downStatus = calculateComplianceStatus(bridgeHeight, downHeight)
        await db.limitPost.create({
          data: {
            bridgeId: bridge.id,
            direction: 'down',
            height: downHeight,
            structureType: structureType || null,
            installDate: installDate,
            hasSensor: hasSensor,
            videoUrl: videoUrl,
            complianceStatus: downStatus
          }
        })

        // 如果状态为红色或黄色，创建预警记录
        if (downStatus === 'red' || downStatus === 'yellow') {
          const reason = downStatus === 'red' 
            ? `限高架净高(${downHeight}m) >= 桥涵净高(${bridgeHeight}m)，存在严重安全隐患`
            : `桥涵净高(${bridgeHeight}m) - 限高架净高(${downHeight}m) < 0.02m，余量不足`
          
          await db.alert.create({
            data: {
              postId: (await db.limitPost.findFirst({ 
                where: { bridgeId: bridge.id, direction: 'down' } 
              }))!.id,
              bridgeId: bridge.id,
              level: downStatus,
              reason,
              status: 'pending',
              createTime: new Date().toISOString().replace('T', ' ').slice(0, 19)
            }
          })
        }

        // 创建上行限高架（如果有）
        if (upHeight !== null) {
          const upStatus = calculateComplianceStatus(bridgeHeight, upHeight)
          await db.limitPost.create({
            data: {
              bridgeId: bridge.id,
              direction: 'up',
              height: upHeight,
              structureType: structureType || null,
              installDate: installDate,
              hasSensor: hasSensor,
              videoUrl: videoUrl,
              complianceStatus: upStatus
            }
          })

          // 如果状态为红色或黄色，创建预警记录
          if (upStatus === 'red' || upStatus === 'yellow') {
            const reason = upStatus === 'red' 
              ? `上行限高架净高(${upHeight}m) >= 桥涵净高(${bridgeHeight}m)，存在严重安全隐患`
              : `上行桥涵净高(${bridgeHeight}m) - 限高架净高(${upHeight}m) < 0.02m，余量不足`
            
            await db.alert.create({
              data: {
                postId: (await db.limitPost.findFirst({ 
                  where: { bridgeId: bridge.id, direction: 'up' } 
                }))!.id,
                bridgeId: bridge.id,
                level: upStatus,
                reason,
                status: 'pending',
                createTime: new Date().toISOString().replace('T', ' ').slice(0, 19)
              }
            })
          }
        }

        successCount++
      } catch (err) {
        errors.push({ row: rowNum, reason: `数据处理错误: ${err instanceof Error ? err.message : '未知错误'}` })
      }
    }

    return NextResponse.json({
      message: '导入完成',
      successCount,
      failCount: errors.length,
      errors: errors.slice(0, 50) // 最多返回50条错误
    })
  } catch (error) {
    console.error('导入失败:', error)
    return NextResponse.json({ error: '导入失败，请检查文件格式' }, { status: 500 })
  }
}
